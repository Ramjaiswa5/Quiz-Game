package com.freak.mathsgame

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat

class SubtractionActivity : AppCompatActivity() {

    private var Name:String?=null
    private var score:Int=0

    private var currentPosition:Int=1
    private var questionList:ArrayList<QuestionData> ? = null
    private var selecedOption:Int=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subtraction)

        val opt_1 :TextView
        opt_1=findViewById(R.id.opt_1)
        val opt_2 :TextView
        opt_2=findViewById(R.id.opt_2)
        val opt_3 :TextView
        opt_3=findViewById(R.id.opt_3)
        val opt_4 :TextView
        opt_4=findViewById(R.id.opt_4)

        Name=intent.getStringExtra(setData.name)

        questionList=setData.Subtraction()

        setQuestion()

        opt_1.setOnClickListener{

            selectedOptionStyle(opt_1,1)
        }
        opt_2.setOnClickListener{

            selectedOptionStyle(opt_2,2)
        }
        opt_3.setOnClickListener{

            selectedOptionStyle(opt_3,3)
        }
        opt_4.setOnClickListener{

            selectedOptionStyle(opt_4,4)
        }

        val submit :TextView
        submit=findViewById(R.id.submit)

        submit.setOnClickListener {
            if(selecedOption!=0)
            {
                val question=questionList!![currentPosition-1]
                if(selecedOption!=question.correct_ans)
                {
                    setColor(selecedOption,R.drawable.wrong_question_option)
                }else{
                    score++;
                }
                setColor(question.correct_ans,R.drawable.correct_question_option)
                if(currentPosition==questionList!!.size)
                    submit.text="FINISH"
                else
                    submit.text="Go to Next"
            }else{
                currentPosition++
                when{
                    currentPosition<=questionList!!.size->{
                        setQuestion()
                    }
                    else->{
                        var intent= Intent(this,Result::class.java)
                        intent.putExtra(setData.name,Name.toString())
                        intent.putExtra(setData.score,score.toString())
                        intent.putExtra("total size",questionList!!.size.toString())

                        startActivity(intent)
                        finish()
                    }
                }
            }
            selecedOption=0
        }

    }

    fun setColor(opt:Int,color:Int){
        val opt_1 :TextView
        opt_1=findViewById(R.id.opt_1)
        val opt_2 :TextView
        opt_2=findViewById(R.id.opt_2)
        val opt_3 :TextView
        opt_3=findViewById(R.id.opt_3)
        val opt_4 :TextView
        opt_4=findViewById(R.id.opt_4)

        when(opt){
            1->{
                opt_1.background=ContextCompat.getDrawable(this,color)
            }
            2->{
                opt_2.background=ContextCompat.getDrawable(this,color)
            }
            3->{
                opt_3.background=ContextCompat.getDrawable(this,color)
            }
            4->{
                opt_4.background=ContextCompat.getDrawable(this,color)
            }
        }
    }


    fun setQuestion(){

        val question = questionList!![currentPosition-1]
        setOptionStyle()

        val opt_1 :TextView
        opt_1=findViewById(R.id.opt_1)
        val opt_2 :TextView
        opt_2=findViewById(R.id.opt_2)
        val opt_3 :TextView
        opt_3=findViewById(R.id.opt_3)
        val opt_4 :TextView
        opt_4=findViewById(R.id.opt_4)

        val progress_bar:ProgressBar
        progress_bar=findViewById(R.id.progress_bar)
        val progress_text:TextView
        progress_text=findViewById(R.id.progress_text)
        val question_text:TextView
        question_text=findViewById(R.id.question_text)


        progress_bar.progress=currentPosition
        progress_bar.max=questionList!!.size
        progress_text.text="${currentPosition}"+"/"+"${questionList!!.size}"
        question_text.text=question.question
        opt_1.text=question.option_one
        opt_2.text=question.option_tw0
        opt_3.text=question.option_three
        opt_4.text=question.option_four

    }

    fun setOptionStyle(){

        val opt_1 :TextView
        opt_1=findViewById(R.id.opt_1)
        val opt_2 :TextView
        opt_2=findViewById(R.id.opt_2)
        val opt_3 :TextView
        opt_3=findViewById(R.id.opt_3)
        val opt_4 :TextView
        opt_4=findViewById(R.id.opt_4)

        var optionList:ArrayList<TextView> = arrayListOf()
        optionList.add(0,opt_1)
        optionList.add(1,opt_2)
        optionList.add(2,opt_3)
        optionList.add(3,opt_4)

        for(op in optionList)
        {
            op.setTextColor(Color.parseColor("#555151"))
            op.background=ContextCompat.getDrawable(this,R.drawable.question_option)
            op.typeface= Typeface.DEFAULT
        }
    }

    fun selectedOptionStyle(view:TextView,opt:Int){

        setOptionStyle()
        selecedOption=opt
        view.background=ContextCompat.getDrawable(this,R.drawable.selected_question_option)
        view.typeface= Typeface.DEFAULT_BOLD
        view.setTextColor(Color.parseColor("#000000"))

    }
}