package com.freak.mathsgame

object setData {

    const val name: String = "name"
    const val score: String = "score"

    fun Addition(): ArrayList<QuestionData> {
        var que: ArrayList<QuestionData> = arrayListOf()

        var question1 = QuestionData(
            1,
            "27 + 49 ?",

            "67",
            "66",
            "86",
            "76",
            4
        )
        var question2 = QuestionData(
            2,
            "93 + 69 ?",

            "162",
            "152",
            "172",
            "None of the above",
            1
        )
        var question3 = QuestionData(
            3,
            "58 + 13 ?",

            "81",
            "71",
            "61",
            "91",
            2
        )
        var question4 = QuestionData(
            4,
            "54 + 23 ?",

            "67",
            "87",
            "77",
            "76",
            3
        )

        var question5 = QuestionData(
            5,
            "16 + 22 ?",

            "28",
            "39",
            "48",
            "None of the above",
            4
        )

        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
    fun Subtraction(): ArrayList<QuestionData> {
        var que: ArrayList<QuestionData> = arrayListOf()

        var question1 = QuestionData(
            1,
            "27 - 49 ?",

            "22",
            "32",
            "-32",
            "-22",
            4
        )
        var question2 = QuestionData(
            2,
            "93 - 69 ?",

            "24",
            "14",
            "34",
            "None of the above",
            1
        )
        var question3 = QuestionData(
            3,
            "58 - 13 ?",

            "55",
            "45",
            "35",
            "60",
            2
        )
        var question4 = QuestionData(
            4,
            "54 - 23 ?",

            "21",
            "41",
            "31",
            "13",
            3
        )

        var question5 = QuestionData(
            5,
            "96 - 22 ?",

            "78",
            "79",
            "68",
            "74",
            4
        )

        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
    fun Multiplication(): ArrayList<QuestionData> {
        var que: ArrayList<QuestionData> = arrayListOf()

        var question1 = QuestionData(
            1,
            "17 * 9 ?",

            "176",
            "166",
            "156",
            "153",
            4
        )
        var question2 = QuestionData(
            2,
            "13 * 6 ?",

            "78",
            "68",
            "88",
            "18",
            1
        )
        var question3 = QuestionData(
            3,
            "9 * 8 ?",

            "81",
            "72",
            "71",
            "91",
            2
        )
        var question4 = QuestionData(
            4,
            "5 * 18 ?",

            "82",
            "85",
            "90",
            "95",
            3
        )

        var question5 = QuestionData(
            5,
            "11 * 12 ?",

            "128",
            "133",
            "123",
            "132",
            4
        )

        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
    fun Division(): ArrayList<QuestionData> {
        var que: ArrayList<QuestionData> = arrayListOf()

        var question1 = QuestionData(
            1,
            "105 / 3 ?",

            "34",
            "36",
            "45",
            "35",
            4
        )
        var question2 = QuestionData(
            2,
            "93 / 6 ?",

            "15.5",
            "15.3",
            "15",
            "None of the above",
            1
        )
        var question3 = QuestionData(
            3,
            "78 / 6 ?",

            "14",
            "13",
            "12",
            "11",
            2
        )
        var question4 = QuestionData(
            4,
            "124 / 2 ?",

            "67",
            "64",
            "62",
            "52",
            3
        )

        var question5 = QuestionData(
            5,
            "36 / 6 ?",

            "7",
            "5",
            "4",
            "6",
            4
        )

        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
}