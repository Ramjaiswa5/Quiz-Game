package com.freak.mathsgame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    lateinit var drawerlayout: DrawerLayout
    lateinit var navigationView: NavigationView
    lateinit var toggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //navigation
        drawerlayout = findViewById(R.id.drawerlayout)
        navigationView = findViewById(R.id.navigationview)
        toggle = ActionBarDrawerToggle(this@MainActivity,drawerlayout,R.string.open,R.string.close)
        drawerlayout.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val button2:Button
        button2=findViewById(R.id.button2)
        button2.setOnClickListener {
            var intent = Intent(this,AdditionActivity::class.java)
            startActivity(intent)
        }
        val button3:Button
        button3=findViewById(R.id.button3)
        button3.setOnClickListener {
            var intent = Intent(this,SubtractionActivity::class.java)
            startActivity(intent)
        }
        val button4:Button
        button4=findViewById(R.id.button4)
        button4.setOnClickListener {
            var intent = Intent(this,MultiplicationActivity::class.java)
            startActivity(intent)
        }
        val button5:Button
        button5=findViewById(R.id.button5)
        button5.setOnClickListener {
            var intent = Intent(this,DivisionActivity::class.java)
            startActivity(intent)
        }


        navigationView.setNavigationItemSelectedListener {
            when(it.itemId){
                R.id.add -> {
                    var intent = Intent(this,AdditionActivity::class.java)
                    startActivity(intent)
                }
                R.id.sub -> {
                    var intent = Intent(this,SubtractionActivity::class.java)
                    startActivity(intent)
                }
                R.id.mul -> {
                    var intent = Intent(this,MultiplicationActivity::class.java)
                    startActivity(intent)
                }
                R.id.div-> {
                    var intent = Intent(this,DivisionActivity::class.java)
                    startActivity(intent)
                }
            }
            true
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (toggle.onOptionsItemSelected(item)){
            return true
        }

        return true

    }

}